<?php echo 'Hallo, ini Dinar Titian! dari Universitas Dian Nuswantoro, Prodi Teknik Informatika'; ?>
